from bingdog.executor import TaskExecutor
from bingdog.appconfig import Configurator
import sys

sys.path.append("/usr/local/src") # This is not necessary. It depends on the site-package configuration of your application environment.
Configurator.initialize(Configurator, "/usr/local/src/sample_batched_data_processing/bdp.yaml") # This file was created at step 2.
executor = TaskExecutor()
executor.execute("init_parameters") # The task ID of the first task.