drop database if exists `$db_name`;

CREATE DATABASE `$db_name` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

use $db_name;

create table if not exists daily_record_$fetch_year(
    record_id int(10) primary key not null auto_increment,
    code varchar(6) not null,
    record_date varchar(8) not null,
    change_value double(30, 20) not null,
    change_percentage double(30,20) not null,
    close_price double(30,20) not null,
    opening_price double(30, 20) not null,
    highest_price double(30, 20) not null,
    lowest_price double(30, 20) not null,
    last_close_price double(30, 20) not null,
    turnover_ratio double(30, 20) not null,  
    turnover_amount double(50, 20) not null,
    turnover_qty double(50, 20) not null,
    tcap double(50, 20) not null,
    mcap double(50, 20) not null
);

create index idx_daily_record_code_$fetch_year on daily_record_$fetch_year(code);
create index idx_daily_record_code_date_$fetch_year on daily_record_$fetch_year(code, record_date);